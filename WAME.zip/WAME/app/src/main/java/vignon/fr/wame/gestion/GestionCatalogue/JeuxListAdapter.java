package vignon.fr.wame.gestion.GestionCatalogue;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import vignon.fr.wame.R;

public class JeuxListAdapter extends BaseAdapter {

    private Context context;
    private int layout;
    private ArrayList<Jeux> jeuxList;

    // Constructeur

    public JeuxListAdapter(Context context, int layout, ArrayList<Jeux> jeuxList) {
        this.context = context;
        this.layout = layout;
        this.jeuxList = jeuxList;
    }

    @Override
    public int getCount() {
        return jeuxList.size();
    }

    @Override
    public Object getItem(int position) {
        return jeuxList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        ImageView imageView;
        TextView txtName, txtPrice, txtDesc, txtType;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        View row = view;
        ViewHolder holder = new ViewHolder();

        if (row == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout, null);

            holder.txtName =(TextView) row.findViewById(R.id.txtName);
            holder.txtPrice =(TextView) row.findViewById(R.id.txtPrice);
            holder.txtDesc =(TextView) row.findViewById(R.id.txtDesc);
            holder.txtType =(TextView) row.findViewById(R.id.txtType);
            holder.imageView = (ImageView) row.findViewById(R.id.imgJeux);

            row.setTag(holder);
        }else {
            holder = (ViewHolder) row.getTag();
        }

        Jeux jeux = jeuxList.get(position);

        holder.txtName.setText(jeux.getName());
        holder.txtPrice.setText(jeux.getPrice());
        holder.txtDesc.setText(jeux.getDesc());
        holder.txtType.setText(jeux.getType());

        byte [] jeuxImage = jeux.getImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(jeuxImage, 0, jeuxImage.length);
        holder.imageView.setImageBitmap(bitmap);

        return row;
    }

}
