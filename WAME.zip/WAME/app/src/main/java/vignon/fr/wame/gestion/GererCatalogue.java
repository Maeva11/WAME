package vignon.fr.wame.gestion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import vignon.fr.wame.R;
import vignon.fr.wame.gestion.GestionCatalogue.Ajout;

public class GererCatalogue extends AppCompatActivity {

    Button btnAjout;
    Button btnModif;
    Button btnSupp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gerer_catalogue);

        btnAjout =(Button) findViewById(R.id.ajout);
        btnModif =(Button) findViewById(R.id.modifier);
        btnSupp =(Button) findViewById(R.id.supprimer);

        btnAjout.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent = new Intent(getApplicationContext(), Ajout.class);
        startActivity(intent);
        }

        // FAIRE POUR LES 2 AUTRES BOUTONS
        });
    }
}