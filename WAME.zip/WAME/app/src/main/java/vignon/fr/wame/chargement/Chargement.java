package vignon.fr.wame.chargement;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import vignon.fr.wame.R;
import vignon.fr.wame.formulaire.MainActivity;


public class Chargement extends AppCompatActivity {

    private final int CHARGEMENT_TIMEOUT = 3000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chargement);

        // Rediriger vers la page principale "MainActivity" après 3 secondes
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                // Démarrer une page
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        };
        // handler post delayed
        new Handler().postDelayed(runnable, CHARGEMENT_TIMEOUT);
    }
}