package vignon.fr.wame.gestion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import vignon.fr.wame.R;
import vignon.fr.wame.formulaire.MainActivity;

public class GestionAdmin extends AppCompatActivity {
    Button btnCatalogue;
    Button btnCompte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_admin);

        btnCatalogue =(Button) findViewById(R.id.btncatalogue);
        btnCompte =(Button) findViewById(R.id.btncompte);

        btnCompte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), GererCompte.class);
                startActivity(intent);
            }
        });

        btnCatalogue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), GererCatalogue.class);
                startActivity(intent);
            }
        });
    }
}