package vignon.fr.wame.formulaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import vignon.fr.wame.R;
import vignon.fr.wame.gestion.GererCatalogue;
import vignon.fr.wame.gestion.GestionCatalogue.Ajout;
import vignon.fr.wame.gestion.GestionAdmin;
import vignon.fr.wame.gestion.GestionCatalogue.Jeux;
import vignon.fr.wame.gestion.GestionCatalogue.JeuxList;

// CLass pour le formulaire de connexion

public class LoginActivity extends AppCompatActivity {

    EditText username, password;
    Button btnlogin;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = (EditText) findViewById(R.id.username1);
        password = (EditText) findViewById(R.id.password1);
        btnlogin = (Button) findViewById(R.id.btnsignin1);
        DB = new DBHelper(this, 1);


        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(LoginActivity.this, "Remplir tous les champs", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkuserpass = DB.checkusernamepassword(user, pass);
                    if (checkuserpass == true) {
                        // Si user est admin alors activité gestion
                        if (user.equals("admin")) {
                            Intent intent = new Intent(getApplicationContext(), GestionAdmin.class);
                            startActivity(intent);
                            // si user est gerant alors ajout
                        } else if (user.equals("gerant")) {
                            Intent intent = new Intent(getApplicationContext(), GererCatalogue.class);
                            startActivity(intent);
                        } else {
                            Intent intent = new Intent(getApplicationContext(), JeuxList.class);
                            startActivity(intent);
                        }

                    } else {
                        Toast.makeText(LoginActivity.this, "Invalide", Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });
    }
}
