package vignon.fr.wame.gestion.GestionCatalogue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import vignon.fr.wame.R;

public class Trier extends AppCompatActivity {

    Button PC, XBOX, PS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trier);

        PC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Trier.this, catalogue_PC.class);
                startActivity(intent);
            }
        });
        XBOX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Trier.this, catalogue_PC.class);
                startActivity(intent);
            }
        });
        PS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Trier.this, catalogue_PC.class);
                startActivity(intent);
            }
        });
    }
}