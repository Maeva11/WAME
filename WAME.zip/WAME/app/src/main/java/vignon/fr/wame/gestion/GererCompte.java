package vignon.fr.wame.gestion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import vignon.fr.wame.R;

public class GererCompte extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gerer_compte);
    }
}