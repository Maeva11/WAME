package vignon.fr.wame.gestion.GestionCatalogue;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import vignon.fr.wame.R;

public class catalogue_PS extends AppCompatActivity {

    GridView gridView;
    ArrayList<Jeux> list;
    JeuxListAdapter adapter = null;
    Button button;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jeux_list_activity);

        gridView =(GridView)findViewById(R.id.gridView);
        button= (Button)findViewById(R.id.button);
        list = new ArrayList<>();

        adapter = new JeuxListAdapter(this, R.layout.jeux_items, list);
        gridView.setAdapter(adapter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(catalogue_PS.this, Trier.class);
                startActivity(intent);
            }
        });

        // Get Data from Sqlite
        Cursor cursor = Ajout.sqLiteHelper.getData("SELECT * FROM JEUX WHERE type LIKE '%PS%';");
        list.clear();

        while (cursor.moveToNext() ){
            int id = cursor.getInt(0);

            String name = cursor.getString(1);
            String price = cursor.getString(2);
            String desc = cursor.getString(3);
            String type = cursor.getString(4);
            byte[] image = cursor.getBlob(5);

            list.add(new Jeux (id, name, price, desc, type, image));
        }
        adapter.notifyDataSetChanged();
    }

}
