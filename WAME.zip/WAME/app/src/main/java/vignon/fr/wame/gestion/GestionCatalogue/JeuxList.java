package vignon.fr.wame.gestion.GestionCatalogue;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.Toolbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import vignon.fr.wame.R;

public class JeuxList extends AppCompatActivity {

    GridView gridView;
    ArrayList<Jeux> list;
    JeuxListAdapter adapter = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jeux_list_activity);

        gridView =(GridView)findViewById(R.id.gridView);
        list = new ArrayList<>();

        adapter = new JeuxListAdapter(this, R.layout.jeux_items, list);
        gridView.setAdapter(adapter);

        // Get Data from Sqlite
        Cursor cursor = Ajout.sqLiteHelper.getData("SELECT * FROM JEUX");
        list.clear();

        while (cursor.moveToNext() ){
            int id = cursor.getInt(0);

            String name = cursor.getString(1);
            String price = cursor.getString(2);
            String desc = cursor.getString(3);
            String type = cursor.getString(4);
            byte[] image = cursor.getBlob(5);

            list.add(new Jeux (id, name, price, desc, type, image));
        }
        adapter.notifyDataSetChanged();
    }

    Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar); // get the reference of Toolbar
toolbar.setTitle("AbhiAndroid"); // set Title for Toolbar
toolbar.setLogo(R.drawable.android); // set logo for Toolbar
    setSupportActionBar(toolbar); // Setting/replace toolbar as the ActionBar
}
    // Activity's overrided method used to set the menu file
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
// Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    // Activity's overrided method used to perform click events on menu items
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
// Handle action bar item clicks here. The action bar will
// automatically handle clicks on the Home/Up button, so long
// as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
//noinspection SimplifiableIfStatement
// Display menu item's title by using a Toast.
        if (id == R.id.action_settings) {
            Toast.makeText(getApplicationContext(), "Setting Menu", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.action_search) {
            Toast.makeText(getApplicationContext(), "Search Menu", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.action_user) {
            Toast.makeText(getApplicationContext(), "User Menu", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
}

